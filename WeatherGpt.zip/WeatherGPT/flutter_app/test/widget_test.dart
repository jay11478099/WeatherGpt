import 'package:flutter_test/flutter_test.dart';
import 'package:weathergpt/main.dart';

void main() {
  testWidgets('WeatherGPT app loads', (WidgetTester tester) async {
    await tester.pumpWidget(const WeatherGPTApp());

    expect(find.byType(WeatherGPTApp), findsOneWidget);
  });
}