import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class SignupPage extends StatefulWidget {
  const SignupPage({super.key});
  @override State<SignupPage> createState() => _SignupPageState();
}

class _SignupPageState extends State<SignupPage> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  final _confirm = TextEditingController();
  final _auth = AuthService();
  bool _loading = false;
  bool _hide = true;

  @override void dispose() { _name.dispose(); _email.dispose(); _password.dispose(); _confirm.dispose(); super.dispose(); }
  InputDecoration _field(String label, IconData icon) => InputDecoration(labelText: label, prefixIcon: Icon(icon), filled: true, fillColor: const Color(0xFFEAF3FF), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none), focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: Color(0xFF4A90E2), width: 2)));
  Future<void> _signup() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);
    final result = await _auth.signup(name: _name.text, email: _email.text, password: _password.text);
    if (!mounted) return;
    setState(() => _loading = false);
    final success = result['success'] == true || result['success'] == 1 || result['success'] == '1' || result['success'] == 'true';
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(result['message']?.toString() ?? (success ? 'Account created' : 'Signup failed'))));
    if (success) Navigator.pop(context);
  }
  @override Widget build(BuildContext context) => Scaffold(backgroundColor: const Color(0xFFF4F7FC), body: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 430), child: Card(elevation: 8, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)), child: Padding(padding: const EdgeInsets.all(30), child: Form(key: _formKey, child: Column(children: [Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: const Color(0xFFEAF3FF), borderRadius: BorderRadius.circular(20)), child: const Icon(Icons.cloud_rounded, size: 54, color: Color(0xFF4A90E2))), const SizedBox(height: 18), const Text('Create account', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: Color(0xFF2F3640))), const SizedBox(height: 24), TextFormField(controller: _name, decoration: _field('Full name', Icons.person_outline), validator: (v) => v == null || v.trim().isEmpty ? 'Enter your name' : null), const SizedBox(height: 14), TextFormField(controller: _email, keyboardType: TextInputType.emailAddress, decoration: _field('Email address', Icons.email_outlined), validator: (v) => v == null || !v.contains('@') ? 'Enter a valid email' : null), const SizedBox(height: 14), TextFormField(controller: _password, obscureText: _hide, decoration: _field('Password', Icons.lock_outline), validator: (v) => v == null || v.length < 6 ? 'Use at least 6 characters' : null), const SizedBox(height: 14), TextFormField(controller: _confirm, obscureText: _hide, decoration: _field('Confirm password', Icons.lock_reset_outlined), validator: (v) => v != _password.text ? 'Passwords do not match' : null), const SizedBox(height: 24), SizedBox(width: double.infinity, height: 54, child: ElevatedButton(style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF4A90E2), foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))), onPressed: _loading ? null : _signup, child: _loading ? const CircularProgressIndicator(color: Colors.white) : const Text('CREATE ACCOUNT', style: TextStyle(fontWeight: FontWeight.bold)))), const SizedBox(height: 12), TextButton(onPressed: () => Navigator.pop(context), child: const Text('Already have an account? Login'))]))))))));
}
