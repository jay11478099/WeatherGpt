import 'dart:convert';

import 'package:http/http.dart' as http;

class WeatherData {
  final double temperature;
  final double windSpeed;
  final int weatherCode;
  final int humidity;

  WeatherData({
    required this.temperature,
    required this.windSpeed,
    required this.weatherCode,
    required this.humidity,
  });
}

class ForecastDay {
  final DateTime date;
  final double maxTemperature;
  final double minTemperature;
  final int weatherCode;
  final int rainProbability;

  ForecastDay({
    required this.date,
    required this.maxTemperature,
    required this.minTemperature,
    required this.weatherCode,
    required this.rainProbability,
  });
}

class ForecastData {
  final List<ForecastDay> days;

  ForecastData({required this.days});
}

class WeatherService {
  Future<WeatherData> fetchWeather({
    required double latitude,
    required double longitude,
  }) async {
    final url = Uri.parse(
      'https://api.open-meteo.com/v1/forecast'
      '?latitude=$latitude'
      '&longitude=$longitude'
      '&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m'
      '&timezone=auto',
    );

    final response = await http.get(url);
    if (response.statusCode != 200) {
      throw Exception('Unable to load weather data. Status code: ${response.statusCode}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final current = data['current'] as Map<String, dynamic>;

    return WeatherData(
      temperature: (current['temperature_2m'] as num).toDouble(),
      windSpeed: (current['wind_speed_10m'] as num).toDouble(),
      weatherCode: (current['weather_code'] as num).toInt(),
      humidity: (current['relative_humidity_2m'] as num).toInt(),
    );
  }

  Future<ForecastData> fetchForecast({
    required double latitude,
    required double longitude,
  }) async {
    final url = Uri.parse(
      'https://api.open-meteo.com/v1/forecast'
      '?latitude=$latitude'
      '&longitude=$longitude'
      '&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max'
      '&forecast_days=7'
      '&timezone=auto',
    );

    final response = await http.get(url);
    if (response.statusCode != 200) {
      throw Exception('Unable to load forecast data. Status code: ${response.statusCode}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final daily = data['daily'] as Map<String, dynamic>;
    final dates = daily['time'] as List<dynamic>;
    final maxTemps = daily['temperature_2m_max'] as List<dynamic>;
    final minTemps = daily['temperature_2m_min'] as List<dynamic>;
    final codes = daily['weather_code'] as List<dynamic>;
    final rain = daily['precipitation_probability_max'] as List<dynamic>?;

    final days = List<ForecastDay>.generate(dates.length, (index) {
      return ForecastDay(
        date: DateTime.parse(dates[index] as String),
        maxTemperature: (maxTemps[index] as num).toDouble(),
        minTemperature: (minTemps[index] as num).toDouble(),
        weatherCode: (codes[index] as num).toInt(),
        rainProbability: rain == null || rain[index] == null ? 0 : (rain[index] as num).toInt(),
      );
    });

    return ForecastData(days: days);
  }
}
