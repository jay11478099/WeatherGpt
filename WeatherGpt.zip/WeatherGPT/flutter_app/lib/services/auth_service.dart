import 'dart:convert';
import 'package:http/http.dart' as http;

class AuthService {
  static const String baseUrl = 'http://127.0.0.1/weathergpt_api';

  Future<Map<String, dynamic>> login({required String email, required String password}) async {
    return _post('login.php', {'email': email.trim(), 'password': password});
  }

  Future<Map<String, dynamic>> signup({required String name, required String email, required String password}) async {
    return _post('signup.php', {'name': name.trim(), 'email': email.trim(), 'password': password});
  }

  Future<Map<String, dynamic>> _post(String endpoint, Map<String, dynamic> body) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/$endpoint'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(body),
      );
      if (response.statusCode != 200) {
        return {'success': false, 'message': 'Server error: ${response.statusCode}'};
      }
      final data = jsonDecode(response.body);
      if (data is Map<String, dynamic>) return data;
      return {'success': false, 'message': 'Invalid response from server.'};
    } catch (_) {
      return {'success': false, 'message': 'Cannot connect to backend. Check XAMPP and Apache.'};
    }
  }
}
