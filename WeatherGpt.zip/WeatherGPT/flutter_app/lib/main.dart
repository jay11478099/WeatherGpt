import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http/http.dart' as http;

import 'services/weather_service.dart';
import 'screens/login_page.dart';

final GlobalKey<NavigatorState> navigatorKey =
    GlobalKey<NavigatorState>();

void main() {
  runApp(const WeatherGPTApp());
}

class WeatherGPTApp extends StatelessWidget {
  const WeatherGPTApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'WeatherGPT',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: const Color(0xFFF5F6FA),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF4A90E2),
          brightness: Brightness.light,
        ),
      ),
      navigatorKey: navigatorKey,
      home: LoginPage(
        onLoginSuccess: (userName) {
          navigatorKey.currentState!.pushReplacement(
            MaterialPageRoute(
              builder: (_) => WeatherHomePage(userName: userName),
            ),
          );
        },
      ),
    );
  }
}

class WeatherHomePage extends StatefulWidget {
  final String userName;

  const WeatherHomePage({
    super.key,
    required this.userName,
  });

  @override
  State<WeatherHomePage> createState() {
    return _WeatherHomePageState();
  }
}

class _WeatherHomePageState
    extends State<WeatherHomePage> {
  final TextEditingController questionController =
      TextEditingController();

  WeatherData? weatherData;
  ForecastData? forecastData;
  int selectedIndex = 0;
  bool isLoadingForecast = false;
  String forecastError = '';

  bool isLoadingWeather = true;

  String weatherError = '';

  String userLocationName =
      'Detecting your location...';

  double? userLatitude;
  double? userLongitude;

  String answerText =
      'Ask me anything about weather, travel, '
      'farming, or tomorrow’s forecast.';

  @override
  void initState() {
    super.initState();

    loadWeatherFromDevice();
  }

  // --------------------------------------------------
  // GET DEVICE LOCATION
  // --------------------------------------------------

  Future<void> loadWeatherFromDevice() async {
    setState(() {
      isLoadingWeather = true;
      weatherError = '';
      userLocationName =
          'Detecting your location...';
    });

    try {
      final bool serviceEnabled =
          await Geolocator.isLocationServiceEnabled();

      if (!serviceEnabled) {
        setState(() {
          weatherError =
              'Please enable location services.';
          isLoadingWeather = false;
        });

        return;
      }

      LocationPermission permission =
          await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission =
            await Geolocator.requestPermission();
      }

      if (permission == LocationPermission.denied) {
        setState(() {
          weatherError =
              'Location permission was denied.';
          isLoadingWeather = false;
        });

        return;
      }

      if (permission ==
          LocationPermission.deniedForever) {
        setState(() {
          weatherError =
              'Location permission is permanently denied. '
              'Allow location access in browser settings.';
          isLoadingWeather = false;
        });

        return;
      }

      final Position position =
          await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );

      userLatitude = position.latitude;
      userLongitude = position.longitude;

      final String cityName =
          await getLocationName(
        position.latitude,
        position.longitude,
      );

      final WeatherData weather =
          await WeatherService().fetchWeather(
        latitude: position.latitude,
        longitude: position.longitude,
      );

      if (!mounted) return;

      setState(() {
        weatherData = weather;

        userLocationName = cityName;

        isLoadingWeather = false;
      });
    } catch (error) {
      debugPrint('Location/weather error: $error');

      if (!mounted) return;

      setState(() {
        weatherError =
            'Unable to detect location or load weather.';
        isLoadingWeather = false;
      });
    }
  }

  Future<void> loadForecast() async {
    if (userLatitude == null || userLongitude == null) {
      setState(() {
        forecastError = 'Location is not available yet.';
      });
      return;
    }

    setState(() {
      isLoadingForecast = true;
      forecastError = '';
    });

    try {
      final result = await WeatherService().fetchForecast(
        latitude: userLatitude!,
        longitude: userLongitude!,
      );

      if (!mounted) return;
      setState(() {
        forecastData = result;
        isLoadingForecast = false;
      });
    } catch (error) {
      debugPrint('Forecast error: $error');
      if (!mounted) return;
      setState(() {
        forecastError = 'Unable to load forecast.';
        isLoadingForecast = false;
      });
    }
  }

  // --------------------------------------------------
  // CONVERT COORDINATES INTO CITY NAME
  // --------------------------------------------------

  Future<String> getLocationName(
    double latitude,
    double longitude,
  ) async {
    try {
      final Uri url = Uri.parse(
        'https://api.bigdatacloud.net/data/'
        'reverse-geocode-client'
        '?latitude=$latitude'
        '&longitude=$longitude'
        '&localityLanguage=en',
      );

      final response = await http.get(url);

      if (response.statusCode == 200) {
        final Map<String, dynamic> data =
            jsonDecode(response.body);

        final String city =
            data['city'] ??
            data['locality'] ??
            data['principalSubdivision'] ??
            'Unknown city';

        final String state =
            data['principalSubdivision'] ?? '';

        if (state.isNotEmpty && city != state) {
          return '$city, $state';
        }

        return city;
      }
    } catch (error) {
      debugPrint('Reverse geocoding error: $error');
    }

    return 'Your device location '
        '(${latitude.toStringAsFixed(2)}, '
        '${longitude.toStringAsFixed(2)})';
  }

  // --------------------------------------------------
  // WEATHER DESCRIPTION
  // --------------------------------------------------

  String weatherDescription(int code) {
    if (code == 0) {
      return 'Clear sky';
    }

    if (code == 1 || code == 2 || code == 3) {
      return 'Partly cloudy';
    }

    if (code == 45 || code == 48) {
      return 'Foggy';
    }

    if (code >= 51 && code <= 57) {
      return 'Drizzle';
    }

    if (code >= 61 && code <= 67) {
      return 'Rainy';
    }

    if (code >= 71 && code <= 77) {
      return 'Snowy';
    }

    if (code >= 80 && code <= 82) {
      return 'Rain showers';
    }

    if (code == 85 || code == 86) {
      return 'Snow showers';
    }

    if (code >= 95 && code <= 99) {
      return 'Thunderstorm';
    }

    return 'Unknown weather';
  }

  // --------------------------------------------------
  // WEATHER ICON
  // --------------------------------------------------

  IconData weatherIcon(int code) {
    if (code == 0) {
      return Icons.wb_sunny;
    }

    if (code == 1 || code == 2 || code == 3) {
      return Icons.cloud;
    }

    if (code == 45 || code == 48) {
      return Icons.foggy;
    }

    if (code >= 51 && code <= 67) {
      return Icons.grain;
    }

    if (code >= 71 && code <= 86) {
      return Icons.ac_unit;
    }

    if (code >= 95 && code <= 99) {
      return Icons.thunderstorm;
    }

    return Icons.cloud_outlined;
  }

  // --------------------------------------------------
  // WEATHERGPT DEMO RESPONSE
  // --------------------------------------------------

  void askWeatherGPT(String question) {
    if (question.trim().isEmpty) {
      return;
    }

    String response;

    if (weatherData == null) {
      response =
          'Weather data is still loading. '
          'Please wait a moment and try again.';
    } else {
      final String condition =
          weatherDescription(
        weatherData!.weatherCode,
      );

      response =
          'You asked: "$question"\n\n'
          'Current weather at $userLocationName:\n'
          'Temperature: '
          '${weatherData!.temperature.round()}°C\n'
          'Condition: $condition\n'
          'Humidity: ${weatherData!.humidity}%\n'
          'Wind: '
          '${weatherData!.windSpeed.round()} km/h\n\n'
          'The AI assistant will provide a more '
          'detailed answer after we connect the '
          'WeatherGPT backend.';
    }

    setState(() {
      answerText = response;
      questionController.clear();
    });
  }

  // --------------------------------------------------
  // DISPOSE
  // --------------------------------------------------

  @override
  void dispose() {
    questionController.dispose();

    super.dispose();
  }

  String weekdayName(int weekday) {
    const names = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    if (weekday < 1 || weekday > 7) return '';
    return names[weekday - 1];
  }

  String greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 21) return 'Good evening';
    return 'Good night';
  }

  String formatUserName(String name) {
    final cleaned = name.replaceAll(RegExp(r'[0-9]+$'), '').trim();
    if (cleaned.isEmpty) return 'User';
    return cleaned[0].toUpperCase() + cleaned.substring(1);
  }

  // --------------------------------------------------
  // LOGOUT
  // --------------------------------------------------
  void logout() {
    navigatorKey.currentState!.pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (_) => LoginPage(
          onLoginSuccess: (userName) {
            navigatorKey.currentState!.pushReplacement(
              MaterialPageRoute(
                builder: (_) => WeatherHomePage(
                  userName: userName,
                ),
              ),
            );
          },
        ),
      ),
      (route) => false,
    );
  }

  // --------------------------------------------------
  // MAIN UI
  // --------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        titleSpacing: 24,
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(9),
              decoration: BoxDecoration(
                color: const Color(0xFFEAF4FF),
                borderRadius:
                    BorderRadius.circular(14),
              ),
              child: const Icon(
                Icons.cloud_outlined,
                color: Color(0xFF7DD3FC),
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              'WeatherGPT',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ],
        ),
        actions: [
          IconButton(
            onPressed: loadWeatherFromDevice,
            icon: const Icon(Icons.refresh),
            tooltip:
                'Refresh location and weather',
          ),
          PopupMenuButton<String>(
            tooltip: 'Account menu',
            icon: const Icon(Icons.account_circle_outlined),
            onSelected: (value) {
              if (value == 'logout') {
                logout();
              }
            },
            itemBuilder: (context) => const [
              PopupMenuItem<String>(
                value: 'logout',
                child: Row(
                  children: [
                    Icon(Icons.logout),
                    SizedBox(width: 10),
                    Text('Logout'),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: SafeArea(
        child: selectedIndex == 2
            ? buildForecastPage()
            : Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1200),
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${greeting()}, ${formatUserName(widget.userName)}',
                          style: const TextStyle(
                            color: Color(0xFF2F3640),
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        const Text(
                          'Your intelligent weather assistant',
                          style: TextStyle(
                            fontSize: 16,
                            color: Color(0xFF7F8C8D),
                          ),
                        ),
                        const SizedBox(height: 28),
                        buildWeatherCard(),
                        const SizedBox(height: 28),
                        const Text(
                          'Ask WeatherGPT',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          answerText,
                          style: const TextStyle(
                            color: Color(0xFF7F8C8D),
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 16),
                        buildQuestionBox(),
                        const SizedBox(height: 18),
                        Wrap(
                          spacing: 10,
                          runSpacing: 10,
                          children: [
                            quickQuestion('Will it rain today?'),
                            quickQuestion('Weather tomorrow'),
                            quickQuestion('Travel advice'),
                            quickQuestion('Farming forecast'),
                          ],
                        ),
                        const SizedBox(height: 32),
                        const Text(
                          'Weather Insights',
                          style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 16),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            final bool isSmall = constraints.maxWidth < 650;
                            return GridView.count(
                              crossAxisCount: isSmall ? 2 : 4,
                              crossAxisSpacing: 12,
                              mainAxisSpacing: 12,
                              shrinkWrap: true,
                              physics: const NeverScrollableScrollPhysics(),
                              children: [
                                infoCard(
                                  Icons.water_drop_outlined,
                                  'Humidity',
                                  weatherData != null ? '${weatherData!.humidity}%' : '--%',
                                ),
                                infoCard(
                                  Icons.air,
                                  'Wind',
                                  weatherData != null ? '${weatherData!.windSpeed.round()} km/h' : '-- km/h',
                                ),
                                infoCard(
                                  Icons.location_on_outlined,
                                  'Latitude',
                                  userLatitude != null ? userLatitude!.toStringAsFixed(2) : '--',
                                ),
                                infoCard(
                                  Icons.location_on_outlined,
                                  'Longitude',
                                  userLongitude != null ? userLongitude!.toStringAsFixed(2) : '--',
                                ),
                              ],
                            );
                          },
                        ),
                      ],
                    ),
                  ),
                ),
              ),
      ),
      bottomNavigationBar:
          NavigationBar(
        selectedIndex: selectedIndex,
        onDestinationSelected: (index) {
          setState(() {
            selectedIndex = index;
          });
          if (index == 2 && forecastData == null) {
            loadForecast();
          }
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.chat_bubble_outline),
            selectedIcon: Icon(Icons.chat_bubble),
            label: 'Chat',
          ),
          NavigationDestination(
            icon: Icon(Icons.calendar_month_outlined),
            selectedIcon: Icon(Icons.calendar_month),
            label: 'Forecast',
          ),
          NavigationDestination(
            icon: Icon(Icons.warning_amber_outlined),
            selectedIcon: Icon(Icons.warning),
            label: 'Alerts',
          ),
        ],
      ),
    );
  }

  Widget buildForecastPage() {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 900),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                '7-Day Forecast',
                style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                userLocationName,
                style: const TextStyle(color: Color(0xFF7F8C8D), fontSize: 16),
              ),
              const SizedBox(height: 24),
              if (isLoadingForecast)
                const Center(child: CircularProgressIndicator())
              else if (forecastError.isNotEmpty)
                Center(child: Text(forecastError))
              else if (forecastData == null)
                const Center(child: Text('Forecast is not available yet.'))
              else
                ListView.separated(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: forecastData!.days.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (context, index) {
                    final day = forecastData!.days[index];
                    final date = day.date;
                    final dayName = index == 0 ? 'Today' : weekdayName(date.weekday);
                    return Card(
                      elevation: 0,
                      color: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: ListTile(
                        contentPadding: const EdgeInsets.symmetric(
                          horizontal: 18,
                          vertical: 8,
                        ),
                        leading: Icon(
                          weatherIcon(day.weatherCode),
                          color: const Color(0xFF4A90E2),
                          size: 34,
                        ),
                        title: Text(
                          '$dayName • ${date.day}/${date.month}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        subtitle: Text(
                          '${weatherDescription(day.weatherCode)}\nRain probability: ${day.rainProbability}%',
                        ),
                        isThreeLine: true,
                        trailing: Text(
                          '${day.maxTemperature.round()}° / ${day.minTemperature.round()}°C',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                    );
                  },
                ),
            ],
          ),
        ),
      ),
    );
  }

  // --------------------------------------------------
  // WEATHER CARD
  // --------------------------------------------------

  Widget buildWeatherCard() {
    final int currentWeatherCode =
        weatherData?.weatherCode ?? 0;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF075985),
            Color(0xFF1D4ED8),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius:
            BorderRadius.circular(28),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          final bool isSmall =
              constraints.maxWidth < 600;

          final Widget weatherDetails =
              Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(
                    Icons.location_on_outlined,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      userLocationName,
                      style: const TextStyle(
                        fontSize: 16,
                      ),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 20),

              Text(
                isLoadingWeather
                    ? '...°C'
                    : weatherData != null
                        ? '${weatherData!.temperature.round()}°C'
                        : '--°C',
                style: const TextStyle(
                  fontSize: 64,
                  fontWeight: FontWeight.bold,
                ),
              ),

              Text(
                isLoadingWeather
                    ? 'Loading weather...'
                    : weatherError.isNotEmpty
                        ? weatherError
                        : weatherDescription(
                            currentWeatherCode,
                          ),
                style: const TextStyle(
                  fontSize: 17,
                ),
              ),

              const SizedBox(height: 8),

              Text(
                'Live weather powered by Open-Meteo',
                style: TextStyle(
                  color: Colors.white
                      .withValues(alpha:0.75),
                ),
              ),
            ],
          );

          final Widget weatherIconWidget =
              Icon(
            isLoadingWeather
                ? Icons.cloud_outlined
                : weatherIcon(currentWeatherCode),
            size: 110,
            color: const Color(0xFFBAE6FD),
          );

          if (isSmall) {
            return Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                weatherDetails,
                const SizedBox(height: 24),
                weatherIconWidget,
              ],
            );
          }

          return Row(
            mainAxisAlignment:
                MainAxisAlignment.spaceBetween,
            crossAxisAlignment:
                CrossAxisAlignment.start,
            children: [
              Flexible(
                child: weatherDetails,
              ),
              const SizedBox(width: 24),
              weatherIconWidget,
            ],
          );
        },
      ),
    );
  }

  // --------------------------------------------------
  // QUESTION INPUT
  // --------------------------------------------------

  Widget buildQuestionBox() {
    return TextField(
      controller: questionController,
      onSubmitted: askWeatherGPT,
      decoration: InputDecoration(
        hintText:
            'Ask: Will it rain today?',
        filled: true,
        fillColor:
            Colors.white,
        prefixIcon: const Icon(
          Icons.chat_outlined,
        ),
        suffixIcon: IconButton(
          onPressed: () {
            askWeatherGPT(
              questionController.text,
            );
          },
          icon: const Icon(Icons.send),
          tooltip: 'Ask WeatherGPT',
        ),
        border: OutlineInputBorder(
          borderRadius:
              BorderRadius.circular(18),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  // --------------------------------------------------
  // QUICK QUESTIONS
  // --------------------------------------------------

  Widget quickQuestion(String question) {
    return ActionChip(
      label: Text(question),
      onPressed: () {
        askWeatherGPT(question);
      },
      backgroundColor:
          const Color(0xFFEAF4FF),
      side: BorderSide.none,
    );
  }

  // --------------------------------------------------
  // INSIGHT CARD
  // --------------------------------------------------

  Widget infoCard(
    IconData icon,
    String title,
    String value,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        mainAxisAlignment:
            MainAxisAlignment.center,
        children: [
          Icon(
            icon,
            color: const Color(0xFF7DD3FC),
            size: 28,
          ),

          const SizedBox(height: 12),

          Text(
            title,
            style: TextStyle(
              color: const Color(0xFF7F8C8D),
            ),
          ),

          const SizedBox(height: 5),

          Text(
            value,
            style: const TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}