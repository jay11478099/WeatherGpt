<?php
session_start();
require_once __DIR__ . '/../config/db.php';
if (isset($_GET['logout'])) { session_destroy(); header('Location: index.php'); exit; }
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
  $email=trim($_POST['email']??''); $password=$_POST['password']??'';
  $stmt=$conn->prepare('SELECT id,name,password_hash FROM admins WHERE email=? LIMIT 1');
  $stmt->bind_param('s',$email); $stmt->execute(); $result=$stmt->get_result(); $admin=$result->fetch_assoc();
  if ($admin && hash('sha256',$password)===$admin['password_hash']) { $_SESSION['admin_id']=$admin['id']; $_SESSION['admin_name']=$admin['name']; header('Location: dashboard.php'); exit; }
  $error='Invalid email or password.';
}
if (isset($_SESSION['admin_id'])) { header('Location: dashboard.php'); exit; }
?>
<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>WeatherGPT Admin Login</title><link rel="stylesheet" href="../assets/style.css"></head><body class="login-bg"><div class="login-card"><div class="logo">☁️ WeatherGPT</div><h1>Admin Login</h1><p class="muted">Manage users, searches, chats and alerts.</p><?php if($error): ?><div class="error"><?=htmlspecialchars($error)?></div><?php endif; ?><form method="post"><label>Email</label><input type="email" name="email" required placeholder="admin@weathergpt.local"><label>Password</label><input type="password" name="password" required placeholder="••••••••"><button>Sign in</button></form><div class="hint">Demo admin: admin@weathergpt.local<br>Password: Admin@123</div></div></body></html>
