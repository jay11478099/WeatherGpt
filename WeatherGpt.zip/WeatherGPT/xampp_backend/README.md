# WeatherGPT XAMPP Admin Dashboard

## Setup
1. Start **Apache** and **MySQL** in XAMPP.
2. Copy this folder to `C:\xampp\htdocs\WeatherGPT_XAMPP_Admin_Dashboard`.
3. Open `http://localhost/phpmyadmin`.
4. Import `database.sql`.
5. Open `http://localhost/WeatherGPT_XAMPP_Admin_Dashboard/admin/`.

## Default admin
- Email: `admin@weathergpt.local`
- Password: `Admin@123`

Change the password before using it outside a demo.

## Included
- Admin login/session protection
- Dashboard statistics
- Recent users table
- Popular city searches
- Alert creation and enable/disable
- JSON endpoint for active alerts
- Logging endpoints for weather searches and AI chats

The Flutter app still needs to call the logging endpoints to populate real usage statistics. Add authentication/rate limiting before public deployment.
