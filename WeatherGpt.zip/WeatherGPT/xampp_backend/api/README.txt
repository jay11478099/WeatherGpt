Optional API integration points for the Flutter app:

POST /api/log_search.php   fields: city, user_id(optional)
POST /api/log_chat.php     fields: question, answer, provider, user_id(optional)
GET  /api/alerts.php       returns active alerts as JSON

Add authentication before exposing these endpoints publicly.
