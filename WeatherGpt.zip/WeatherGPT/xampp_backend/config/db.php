<?php
$host = '127.0.0.1';
$user = 'root';
$pass = '';
$db   = 'weathergpt';
$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) { http_response_code(500); die('Database connection failed: ' . $conn->connect_error); }
$conn->set_charset('utf8mb4');
?>
